#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>





void ajouterRDV(GtkButton *button, gpointer user_data);
void creation_contenuTableau(GtkWidget *treeview, const char *nomFichier) ;
void mettreAJourFichierTexte(GtkListStore *toutesLignes);
void supprimerLigne(GtkButton *button, gpointer user_data);
void deplacerLigne(GtkButton *button, gpointer user_data) ;
void liste_archive(GtkButton *button, gpointer user_data);
void bouton_dashboard(GtkButton *button, gpointer user_data);
gint get_new_id();
void save_last_id();
void load_last_id();
void pop_up(GtkWidget *widget, gpointer data);
void enregistrement(GtkButton *button, gpointer user_data)  ;
void ajouterRDV(GtkButton *button, gpointer user_data);



enum {
    COLONNE_ID,
    COLONNE_NOM,
    COLONNE_PRENOM,
    COLONNE_JOUR_SEMAINE,
    COLONNE_DATE,
    COLONNE_HEURE,
    COLONNE_MOTIF,
    NOMBRE_COLONNES
};

// Structure de données pour stocker les entrées du formulaire(utilisé dans enregistrement)
typedef struct {
    GtkWidget *inputNom;
    GtkWidget *inputPrenom;
    GtkWidget *inputJour;
    GtkWidget *inputDate;
    GtkWidget *inputHeure;
    GtkWidget *inputMotif;
} FormData;

gint last_id = 0; // Variable globale pour stocker le dernier ID utilisé




int main(int argc, char *argv[]) {
    // Initialisation de GTK
    gtk_init(&argc, &argv);         


    // Création de la fenêtre
    GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Logiciel de gestion de rendez-vous");   // Titre de la fenêtre
    gtk_window_maximize(GTK_WINDOW(window));                                          // Maximisation de la fenêtre par défaut
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);             // Destruction de la fenêtre quand l'utilisateur clique sur le bouton rouge


    // Création d'un container pour tout le contenu
    GtkWidget *container = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
    gtk_container_add(GTK_CONTAINER(window), container);


    // Affichage de la page d'accueil
    GtkWidget *titrePrincipal = gtk_label_new("Bienvenue sur votre gestion de rendez-vous !"); // Titre de la page d'accueil

    // Modification de la taille de la police du titrePrincipal
    PangoAttrList *attrList = pango_attr_list_new();                //création d'une liste d'attributd qui est utilisé pour stocker les attributs de mise en forme
    PangoAttribute *taille = pango_attr_size_new(32000);              // 32000 représente la taille de la police en unités Pango
    pango_attr_list_insert(attrList, taille);                         //insertion de l'attribut de taille de police dans la liste d'attribut attrList 
    gtk_label_set_attributes(GTK_LABEL(titrePrincipal), attrList);  //application  de la modification dans attrList sur le titrePrincipal
    pango_attr_list_unref(attrList);                                //libération de la mémoire utilisée par attrList après son utilisation

    // Création d'un bouton pour le dashboard
    GtkWidget *dashboard = gtk_button_new_with_label("Voir la liste des RDV en attente");
    g_signal_connect(dashboard, "clicked", G_CALLBACK(bouton_dashboard), window);

    // Création d'un bouton pour le dashboard
    GtkWidget *ajout = gtk_button_new_with_label("Ajouter un nouveau RDV");
    g_signal_connect(ajout, "clicked", G_CALLBACK(ajouterRDV), window);

    GtkWidget *archive = gtk_button_new_with_label("Voir l'archive");
    g_signal_connect(archive, "clicked", G_CALLBACK(liste_archive), window);


    // Ajout des widgets à la boîte verticale
    gtk_box_pack_start(GTK_BOX(container), titrePrincipal, FALSE, TRUE, 125);
    gtk_box_pack_start(GTK_BOX(container), dashboard, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(container), ajout, FALSE, FALSE, 50);
    gtk_box_pack_start(GTK_BOX(container), archive, FALSE, FALSE, 0);


    // Centrage des widgets dans la fenêtre
    gtk_widget_set_halign(titrePrincipal, GTK_ALIGN_CENTER);
    gtk_widget_set_halign(dashboard, GTK_ALIGN_CENTER);
    gtk_widget_set_halign(ajout, GTK_ALIGN_CENTER);
    gtk_widget_set_halign(archive, GTK_ALIGN_CENTER);


    // Affichage de la fenêtre principale
    gtk_widget_show_all(window);


    gtk_main(); // Boucle qui permet de lancer le programme

    return 0;
}

//fonction pour afficher le dashboard
void bouton_dashboard(GtkButton *button, gpointer user_data)
{
    GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Dashboard"); 
    gtk_window_maximize(GTK_WINDOW(window)); 
    GtkWidget *contenudash = gtk_box_new(GTK_ORIENTATION_VERTICAL, 30);
    GtkWidget *contenuTab = gtk_box_new(GTK_ALIGN_CENTER, 5);
    gtk_container_set_border_width(GTK_CONTAINER(contenudash), 100);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);


    //ajout du contenudash à la fenêtre
    gtk_container_add(GTK_CONTAINER(window), contenudash);

    //création titre du tableau
    GtkWidget *titreTab = gtk_label_new("Liste des RDV en attente");

    // Modification de la taille de la police du titrePrincipal
    PangoAttrList *attrList = pango_attr_list_new();                    //création d'une liste d'attribut qui est utilisé pour stocker les attributs de mise en forme
    PangoAttribute *taille = pango_attr_size_new(20000);                  // 32000 représente la taille de la police en unités Pango
    pango_attr_list_insert(attrList, taille);                             //insertion de l'attribut de taille de police dans la liste d'attribut attrList 
    gtk_label_set_attributes(GTK_LABEL(titreTab), attrList);      //application  de la modification dans attrList sur le titrePrincipal
    pango_attr_list_unref(attrList);


    //création du modèle pour le tableau 
    GtkWidget *modTab = gtk_tree_view_new();


    //ajout des contenus du contenudash
    gtk_box_pack_start(GTK_BOX(contenudash), titreTab, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(contenuTab), modTab, FALSE, TRUE, 0);

    // Création d'un widget GtkGrid pour centrer le contenuTab
    GtkWidget *grid = gtk_grid_new();                           //création d'une grille
    gtk_grid_set_row_homogeneous(GTK_GRID(grid), TRUE);         //pour que les lignes ont les mêmes largeur
    gtk_grid_set_column_homogeneous(GTK_GRID(grid), TRUE);         //pour que les lignes ont les mêmes largeur
    gtk_container_add(GTK_CONTAINER(contenudash), grid);            //on ajoute la grille au contenu de la fenêtre

    // Ajout de contenuTab au centre du GtkGrid
    gtk_grid_attach(GTK_GRID(grid), contenuTab, 0, 0, 1, 1);
    gtk_widget_set_halign(contenuTab, GTK_ALIGN_CENTER);
    gtk_widget_set_valign(contenuTab, GTK_ALIGN_CENTER);


    //creation des colonnes(initialisation)
    GtkTreeViewColumn *colonne;
    GtkCellRenderer *rendu;

    //pemière colonne
    rendu= gtk_cell_renderer_text_new();
    colonne = gtk_tree_view_column_new_with_attributes("ID", rendu, "text", COLONNE_ID, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(modTab), colonne);

    //deuxième colonne
    rendu= gtk_cell_renderer_text_new();
    colonne = gtk_tree_view_column_new_with_attributes("Nom", rendu, "text", COLONNE_NOM, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(modTab), colonne);

    //troisième colonne
    rendu= gtk_cell_renderer_text_new();
    colonne = gtk_tree_view_column_new_with_attributes("Prénom", rendu, "text", COLONNE_PRENOM, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(modTab), colonne);

    //quatrième colonne
    rendu= gtk_cell_renderer_text_new();
    colonne = gtk_tree_view_column_new_with_attributes("Jour de la semaine", rendu, "text", COLONNE_JOUR_SEMAINE, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(modTab), colonne);

    //cinquième colonne
    rendu= gtk_cell_renderer_text_new();
    colonne = gtk_tree_view_column_new_with_attributes("Date", rendu, "text", COLONNE_DATE, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(modTab), colonne);

    //sixième colonne
    rendu= gtk_cell_renderer_text_new();
    colonne = gtk_tree_view_column_new_with_attributes("Heure", rendu, "text", COLONNE_HEURE, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(modTab), colonne);

    //septième colonne
    rendu= gtk_cell_renderer_text_new();
    colonne = gtk_tree_view_column_new_with_attributes("Motif", rendu, "text", COLONNE_MOTIF, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(modTab), colonne);

    //création du contenu pour les boutons
    GtkWidget *contenuBouton = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 20);

    //bouton ajouter
    GtkWidget *ajout = gtk_button_new_with_label("Ajouter un nouveau RDV");
    gtk_box_pack_start(GTK_BOX(contenuBouton), ajout, FALSE, FALSE, 0);
    g_signal_connect(ajout, "clicked", G_CALLBACK(ajouterRDV), modTab);

    //bouton voir archive
    GtkWidget *view_archive = gtk_button_new_with_label("Voir l'archive");
    g_signal_connect(view_archive, "clicked", G_CALLBACK(liste_archive), window);
    gtk_box_pack_start(GTK_BOX(contenuBouton), view_archive, FALSE, FALSE, 0);

    //bouton ajouter archive
    GtkWidget *archive = gtk_button_new_with_label("Ajouter aux archives");
    gtk_box_pack_start(GTK_BOX(contenuBouton), archive, FALSE, FALSE, 0);
    g_signal_connect(archive, "clicked", G_CALLBACK(deplacerLigne), modTab);
    g_signal_connect(archive, "clicked", G_CALLBACK(liste_archive), window);

    

    //bouton supprimer
    GtkWidget *supprimer = gtk_button_new_with_label("Supprimer le RDV sélectionné");
    gtk_box_pack_start(GTK_BOX(contenuBouton), supprimer, FALSE, FALSE, 0);
    g_signal_connect(supprimer, "clicked", G_CALLBACK(supprimerLigne), modTab);

    gtk_box_pack_start(GTK_BOX(contenudash), contenuBouton, FALSE, FALSE, 0);

    //pour centrer le contenu du bouton
    GtkWidget *grid2 = gtk_grid_new();                           //création d'une grille
    gtk_grid_set_row_homogeneous(GTK_GRID(grid2), TRUE);         //pour que les lignes ont les mêmes largeur
    gtk_grid_set_column_homogeneous(GTK_GRID(grid2), TRUE);         //pour que les lignes ont les mêmes largeur
    gtk_container_add(GTK_CONTAINER(contenudash), grid2);            //on ajoute la grille au contenu de la fenêtre

    // Ajout de contenuTab au centre du GtkGrid
    gtk_grid_attach(GTK_GRID(grid2), contenuBouton, 0, 0, 1, 1);
    gtk_widget_set_halign(contenuBouton, GTK_ALIGN_CENTER);
    gtk_widget_set_valign(contenuBouton, GTK_ALIGN_CENTER);

    creation_contenuTableau(modTab, "sauvegarde.txt");

    gtk_widget_show_all(window);
    gtk_widget_hide(GTK_WIDGET(user_data));
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


// Fonction pour créer et afficher la fenêtre d'ajout de rendez-vous
void ajouterRDV(GtkButton *button, gpointer user_data) {
    GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Ajout"); 
    gtk_window_maximize(GTK_WINDOW(window)); 
    gtk_container_set_border_width(GTK_CONTAINER(window), 50);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    GtkWidget *contenuAjout = gtk_box_new(GTK_ORIENTATION_VERTICAL, 50);
    GtkWidget *titreAjout = gtk_label_new("Ajoutez un nouveau RDV ici : ");
    gtk_box_pack_start(GTK_BOX(contenuAjout), titreAjout, FALSE, FALSE, 0);

    GtkWidget *grille = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(grille), 20);
    gtk_grid_set_column_spacing(GTK_GRID(grille), 10);

    GtkWidget *labelNom = gtk_label_new("Nom :");
    gtk_grid_attach(GTK_GRID(grille), labelNom, 0, 0, 1, 1);
    GtkWidget *inputNom = gtk_entry_new();
    gtk_grid_attach(GTK_GRID(grille), inputNom, 1, 0, 1, 1);

    GtkWidget *labelPrenom = gtk_label_new("Prénom :");
    gtk_grid_attach(GTK_GRID(grille), labelPrenom, 0, 1, 1, 1);
    GtkWidget *inputPrenom = gtk_entry_new();
    gtk_grid_attach(GTK_GRID(grille), inputPrenom, 1, 1, 1, 1);

    //jour de la semaine
    GtkWidget *labelJour = gtk_label_new("Jour de la semaine :");
    gtk_grid_attach(GTK_GRID(grille), labelJour, 0, 2, 1, 1);
    GtkWidget *inputJour = gtk_entry_new();
    gtk_grid_attach(GTK_GRID(grille), inputJour, 1, 2, 1, 1);

    //date
    GtkWidget *labelDate = gtk_label_new("Date ( jj/mm/aaaa ) :");
    gtk_grid_attach(GTK_GRID(grille), labelDate, 0, 3, 1, 1);
    GtkWidget *inputDate = gtk_entry_new();
    gtk_grid_attach(GTK_GRID(grille), inputDate, 1, 3, 1, 1);

    //heure
    GtkWidget *labelHeure = gtk_label_new("Heure :");
    gtk_grid_attach(GTK_GRID(grille), labelHeure, 0, 4, 1, 1);
    GtkWidget *inputHeure = gtk_entry_new();
    gtk_grid_attach(GTK_GRID(grille), inputHeure, 1, 4, 1, 1);

    //motif
    GtkWidget *labelMotif = gtk_label_new("Motif :");
    gtk_grid_attach(GTK_GRID(grille), labelMotif, 0, 5, 1, 1);
    GtkWidget *inputMotif = gtk_entry_new();
    gtk_grid_attach(GTK_GRID(grille), inputMotif, 1, 5, 1, 1);


    GtkWidget *donnees[6];
    donnees[0] = inputNom;
    donnees[1] = inputPrenom;
    donnees[2] = inputJour;
    donnees[3] = inputDate;
    donnees[4] = inputHeure;
    donnees[5] = inputMotif;

    // Création d'une structure FormData pour stocker les données du formulaire
    FormData *formData = g_new(FormData, 1);
    formData->inputNom = inputNom;
    formData->inputPrenom = inputPrenom;
    formData->inputJour = inputJour;
    formData->inputDate = inputDate;
    formData->inputHeure = inputHeure;
    formData->inputMotif = inputMotif;
    
    

    // Création d'un widget GtkGrid pour le formulaire
    GtkWidget *contour = gtk_grid_new();                           //création d'une grille
    gtk_grid_set_row_homogeneous(GTK_GRID(contour), TRUE);         //pour que les lignes ont les mêmes largeur
    gtk_grid_set_column_homogeneous(GTK_GRID(contour), TRUE);         //pour que les lignes ont les mêmes largeur
    gtk_container_add(GTK_CONTAINER(contenuAjout), contour);            //on ajoute la grille au contenu de la fenêtre


    // Ajout de contenuTab au centre du GtkGrid
    gtk_grid_attach(GTK_GRID(contour), grille, 0, 0, 1, 1);
    gtk_widget_set_halign(grille, GTK_ALIGN_CENTER);
    gtk_widget_set_valign(grille, GTK_ALIGN_CENTER);

    GtkWidget *contenuBouton = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 20);

    //creéation du bouton enregistrer
    GtkWidget *enregistrer = gtk_button_new_with_label("Enregistrer");
    g_signal_connect(enregistrer, "clicked", G_CALLBACK(enregistrement), formData);
    g_signal_connect(enregistrer, "clicked", G_CALLBACK(pop_up), NULL);
    gtk_box_pack_start(GTK_BOX(contenuBouton), enregistrer, FALSE, TRUE, 0);

    GtkWidget *dashboard = gtk_button_new_with_label("Voir le dashboard");
    g_signal_connect(dashboard, "clicked", G_CALLBACK(bouton_dashboard), window);
    gtk_box_pack_start(GTK_BOX(contenuBouton), dashboard, FALSE, TRUE, 0);

    // Création d'un widget GtkGrid pour le formulaire
    GtkWidget *contour2 = gtk_grid_new();                           //création d'une grille
    gtk_grid_set_row_homogeneous(GTK_GRID(contour2), TRUE);         //pour que les lignes ont les mêmes largeur
    gtk_grid_set_column_homogeneous(GTK_GRID(contour2), TRUE);         //pour que les lignes ont les mêmes largeur
    gtk_container_add(GTK_CONTAINER(contenuAjout), contour2);            //on ajoute la grille au contenu de la fenêtre


    // Ajout de contenuTab au centre du GtkGrid
    gtk_grid_attach(GTK_GRID(contour2), contenuBouton, 0, 0, 1, 1);
    gtk_widget_set_halign(contenuBouton, GTK_ALIGN_CENTER);
    gtk_widget_set_valign(contenuBouton, GTK_ALIGN_CENTER);

    gtk_container_add(GTK_CONTAINER(window), contenuAjout);
    gtk_container_add(GTK_CONTAINER(contenuAjout), contour);

    
    gtk_widget_show_all(window);
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



//pour incrémenter automatiquement l'ID

// Fonction pour obtenir le nouvel ID en l'incrémentant
gint get_new_id() {
    return ++last_id;
}

// Fonction pour enregistrer le dernier ID utilisé dans un fichier
void save_last_id() {
    FILE *file = fopen("last_id.txt", "w");
    if (file != NULL) {
        fprintf(file, "%d", last_id);
        fclose(file);
    } else {
        printf("Erreur lors de l'ouverture du fichier pour enregistrer le dernier ID.\n");
    }
}

// Fonction pour charger le dernier ID utilisé à partir du fichier
void load_last_id() {
    FILE *file = fopen("last_id.txt", "r");
    if (file != NULL) {
        fscanf(file, "%d", &last_id);
        fclose(file);
    } else {
        printf("Fichier du dernier ID introuvable. Initialisation de l'ID à zéro.\n");
        last_id = 0;
    }
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


//pour le message en pop-up
void pop_up(GtkWidget *widget, gpointer data) {
    GtkWidget *message;
    message = gtk_message_dialog_new(NULL,
                                     GTK_DIALOG_MODAL,
                                     GTK_MESSAGE_INFO,
                                     GTK_BUTTONS_OK,
                                     "Nouveau rendez-vous enregistré avec succès !");
    gtk_dialog_run(GTK_DIALOG(message));
    gtk_widget_destroy(message);
}


// Fonction pour enregistrer les données entrées dans le form
void enregistrement(GtkButton *button, gpointer user_data) {
    FormData *data = (FormData *)user_data;
    const gchar *nom = gtk_entry_get_text(GTK_ENTRY(data->inputNom));
    const gchar *prenom = gtk_entry_get_text(GTK_ENTRY(data->inputPrenom));
    const gchar *jour = gtk_entry_get_text(GTK_ENTRY(data->inputJour));
    const gchar *date = gtk_entry_get_text(GTK_ENTRY(data->inputDate));
    const gchar *heure = gtk_entry_get_text(GTK_ENTRY(data->inputHeure));
    const gchar *motif = gtk_entry_get_text(GTK_ENTRY(data->inputMotif));

    g_print("Nom: %s\n", nom);
    g_print("Prénom: %s\n", prenom);
    g_print("Jour de la semaine: %s\n", jour);
    g_print("Date: %s\n", date);
    g_print("Heure: %s\n", heure);
    g_print("Motif: %s\n", motif);
    load_last_id();
    gint new_id = get_new_id();

    // Écrire les données dans un fichier texte
    FILE *file = fopen("sauvegarde.txt", "a");
    if (file != NULL) {
        fprintf(file, "%d %s %s %s %s %s %s\n", new_id, nom, prenom, jour, date, heure, motif);
        fclose(file);        
    } else {
        g_print("Erreur lors de l'ouverture du fichier.\n");
    }
    save_last_id();
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



//fonction pour créer l'archive
void liste_archive(GtkButton *button, gpointer user_data)
{
    GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Archives"); 
    gtk_window_maximize(GTK_WINDOW(window)); 
    GtkWidget *contenudash = gtk_box_new(GTK_ORIENTATION_VERTICAL, 30);
    GtkWidget *contenuTab = gtk_box_new(GTK_ALIGN_CENTER, 5);
    gtk_container_set_border_width(GTK_CONTAINER(contenudash), 100);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);


    //ajout du contenudash à la fenêtre
    gtk_container_add(GTK_CONTAINER(window), contenudash);

    //création titre du tableau
    GtkWidget *titreArchive = gtk_label_new("Liste des RDV placés aux archives");

    // Modification de la taille de la police du titrePrincipal
    PangoAttrList *attrList = pango_attr_list_new();                    //création d'une liste d'attribut qui est utilisé pour stocker les attributs de mise en forme
    PangoAttribute *taille = pango_attr_size_new(20000);                  // 32000 représente la taille de la police en unités Pango
    pango_attr_list_insert(attrList, taille);                             //insertion de l'attribut de taille de police dans la liste d'attribut attrList 
    gtk_label_set_attributes(GTK_LABEL(titreArchive), attrList);      //application  de la modification dans attrList sur le titrePrincipal
    pango_attr_list_unref(attrList);


    //création du modèle pour le tableau 
    GtkWidget *modTab = gtk_tree_view_new();


    //ajout des contenus du contenudash
    gtk_box_pack_start(GTK_BOX(contenudash), titreArchive, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(contenuTab), modTab, FALSE, TRUE, 0);

    // Création d'un widget GtkGrid pour centrer le contenuTab
    GtkWidget *grid = gtk_grid_new();                           //création d'une grille
    gtk_grid_set_row_homogeneous(GTK_GRID(grid), TRUE);         //pour que les lignes ont les mêmes largeur
    gtk_grid_set_column_homogeneous(GTK_GRID(grid), TRUE);         //pour que les lignes ont les mêmes largeur
    gtk_container_add(GTK_CONTAINER(contenudash), grid);            //on ajoute la grille au contenu de la fenêtre

    // Ajout de contenuTab au centre du GtkGrid
    gtk_grid_attach(GTK_GRID(grid), contenuTab, 0, 0, 1, 1);
    gtk_widget_set_halign(contenuTab, GTK_ALIGN_CENTER);
    gtk_widget_set_valign(contenuTab, GTK_ALIGN_CENTER);


    //creation des colonnes(initialisation)
    GtkTreeViewColumn *colonne;
    GtkCellRenderer *rendu;

    //pemière colonne
    rendu= gtk_cell_renderer_text_new();
    colonne = gtk_tree_view_column_new_with_attributes("ID", rendu, "text", COLONNE_ID, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(modTab), colonne);

    //deuxième colonne
    rendu= gtk_cell_renderer_text_new();
    colonne = gtk_tree_view_column_new_with_attributes("Nom", rendu, "text", COLONNE_NOM, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(modTab), colonne);

    //troisième colonne
    rendu= gtk_cell_renderer_text_new();
    colonne = gtk_tree_view_column_new_with_attributes("Prénom", rendu, "text", COLONNE_PRENOM, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(modTab), colonne);

    //quatrième colonne
    rendu= gtk_cell_renderer_text_new();
    colonne = gtk_tree_view_column_new_with_attributes("Jour de la semaine", rendu, "text", COLONNE_JOUR_SEMAINE, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(modTab), colonne);

    //cinquième colonne
    rendu= gtk_cell_renderer_text_new();
    colonne = gtk_tree_view_column_new_with_attributes("Date", rendu, "text", COLONNE_DATE, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(modTab), colonne);

    //sixième colonne
    rendu= gtk_cell_renderer_text_new();
    colonne = gtk_tree_view_column_new_with_attributes("Heure", rendu, "text", COLONNE_HEURE, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(modTab), colonne);

    //septième colonne
    rendu= gtk_cell_renderer_text_new();
    colonne = gtk_tree_view_column_new_with_attributes("Motif", rendu, "text", COLONNE_MOTIF, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(modTab), colonne);

    //création du contenu pour les boutons
    GtkWidget *contenuBouton = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 20);

    //bouton ajouter
    GtkWidget *dashboard = gtk_button_new_with_label("Voir le dashboard");
    gtk_box_pack_start(GTK_BOX(contenuBouton), dashboard, FALSE, FALSE, 0);
    g_signal_connect(dashboard, "clicked", G_CALLBACK(bouton_dashboard), window);


    gtk_box_pack_start(GTK_BOX(contenudash), contenuBouton, FALSE, FALSE, 0);

    //pour centrer le contenu du bouton
    GtkWidget *grid2 = gtk_grid_new();                           //création d'une grille
    gtk_grid_set_row_homogeneous(GTK_GRID(grid2), TRUE);         //pour que les lignes ont les mêmes largeur
    gtk_grid_set_column_homogeneous(GTK_GRID(grid2), TRUE);         //pour que les lignes ont les mêmes largeur
    gtk_container_add(GTK_CONTAINER(contenudash), grid2);            //on ajoute la grille au contenu de la fenêtre

    // Ajout de contenuTab au centre du GtkGrid
    gtk_grid_attach(GTK_GRID(grid2), contenuBouton, 0, 0, 1, 1);
    gtk_widget_set_halign(contenuBouton, GTK_ALIGN_CENTER);
    gtk_widget_set_valign(contenuBouton, GTK_ALIGN_CENTER);

    creation_contenuTableau(modTab, "archives.txt");

    gtk_widget_show_all(window);
    gtk_widget_hide(GTK_WIDGET(user_data));
}


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



// Fonction pour supprimer une ligne du tableau et la déplacer vers un fichier
void deplacerLigne(GtkButton *button, gpointer user_data) {
    // Récupération du modèle de données du tableau d'origine à partir du GtkTreeView
    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(user_data));
    // Récupération du modèle de données du tableau d'origine
    GtkListStore *listeOrigine = GTK_LIST_STORE(model);
    
    GtkTreeSelection *selection;
    GtkTreeIter iter;

    // Récupération de la sélection
    selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(user_data));

    // Obtention de l'itérateur de la ligne sélectionnée
    if (gtk_tree_selection_get_selected(selection, &model, &iter)) {
        // Récupération des données de la ligne sélectionnée
        gint id;
        gchar *nom, *prenom, *jour, *date, *heure, *motif;
        gtk_tree_model_get(model, &iter, COLONNE_ID, &id, COLONNE_NOM, &nom, COLONNE_PRENOM, &prenom, COLONNE_JOUR_SEMAINE, &jour, COLONNE_DATE, &date, COLONNE_HEURE, &heure, COLONNE_MOTIF, &motif, -1);

        // Suppression de la ligne du modèle d'origine
        gtk_list_store_remove(listeOrigine, &iter);

        //miseà jour du fichier texte
        mettreAJourFichierTexte(listeOrigine);

        
        // transfert dans archives.txt
        FILE *fichierDestination = fopen("archives.txt", "a");
        if (fichierDestination != NULL) {
            fprintf(fichierDestination, "%d %s %s %s %s %s %s\n", id, nom, prenom, jour, date, heure, motif);
            fclose(fichierDestination);
        }
        
        // Libération de la mémoire allouée pour les chaînes de caractères
        g_free(nom);
        g_free(prenom);
        g_free(jour);
        g_free(date);
        g_free(heure);
        g_free(motif);
    }
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


void supprimerLigne(GtkButton *button, gpointer user_data) {
    GtkTreeSelection *selection;
    GtkTreeModel *model;
    GtkTreeIter iter;

    // Récupération de la sélection
    selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(user_data));

    // Obtention de l'itérateur de la ligne sélectionnée
    if (gtk_tree_selection_get_selected(selection, &model, &iter)) {
        // Suppression de la ligne du modèle
        gtk_list_store_remove(GTK_LIST_STORE(model), &iter);

        //miseà jour du fichier texte
        mettreAJourFichierTexte(GTK_LIST_STORE(model));
    }
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

// Déclaration de la fonction pour mettre à jour le fichier texte
void mettreAJourFichierTexte(GtkListStore *toutesLignes) {
    FILE *fichier = fopen("sauvegarde.txt", "w");
    if (fichier == NULL) {
        g_print("Erreur lors de l'ouverture du fichier.\n");
        return;
    }

    GtkTreeIter iter;
    gboolean valid = gtk_tree_model_get_iter_first(GTK_TREE_MODEL(toutesLignes), &iter);
    while (valid) {
        // Récupération des données de la ligne
        gint id;
        gchar *nom, *prenom, *jour, *date, *heure, *motif;
        gtk_tree_model_get(GTK_TREE_MODEL(toutesLignes), &iter, COLONNE_ID, &id, COLONNE_NOM, &nom, COLONNE_PRENOM, &prenom, COLONNE_JOUR_SEMAINE, &jour, COLONNE_DATE, &date, COLONNE_HEURE, &heure, COLONNE_MOTIF, &motif, -1);

        // Écriture dans le fichier texte
        fprintf(fichier, "%d %s %s %s %s %s %s\n", id, nom, prenom, jour, date, heure, motif);

        // Libération de la mémoire allouée pour les chaînes de caractères
        g_free(nom);
        g_free(prenom);
        g_free(jour);
        g_free(date);
        g_free(heure);
        g_free(motif);

        // Passage à la ligne suivante
        valid = gtk_tree_model_iter_next(GTK_TREE_MODEL(toutesLignes), &iter);
    }

    fclose(fichier);
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


//fonction pour créer le contenu de chaque tableau
void creation_contenuTableau(GtkWidget *treeview, const char *nomFichier) {

    GtkListStore *toutesLignes;
    GtkTreeIter chLigne;

    
    // Création du modèle de données
    toutesLignes = gtk_list_store_new(NOMBRE_COLONNES, G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);


    // Ouvrir le fichier en mode lecture
    FILE *fichier = fopen(nomFichier, "r");
    if (fichier == NULL) {
        g_print("Erreur lors de l'ouverture du fichier.\n");
        return;
    }

    // Lire chaque ligne du fichier
    char ligne[256];
    while (fgets(ligne, sizeof(ligne), fichier)) {
        // Diviser la ligne en colonnes en utilisant les espaces comme délimiteurs
        char *id_str, *nom_str, *prenom_str, *jour_str, *date_str, *heure_str, *motif_str;
        id_str = strtok(ligne, " ");
        nom_str = strtok(NULL, " ");
        prenom_str = strtok(NULL, " ");
        jour_str = strtok(NULL, " ");                       //strtok permet de délimiter les caractères à mettre dans la colonne 
        date_str = strtok(NULL, " ");
        heure_str = strtok(NULL, " ");
        motif_str = strtok(NULL, "\n");

        // Ajouter la ligne au GtkListStore
        gtk_list_store_append(toutesLignes, &chLigne);
        gtk_list_store_set(toutesLignes, &chLigne,                  //on place les valeurs obtenues précédemment dans le tableau
                           COLONNE_ID, atoi(id_str),            //on convertit le "id" de type int en strrrrrrrrrring
                           COLONNE_NOM, nom_str, 
                           COLONNE_PRENOM, prenom_str, 
                           COLONNE_JOUR_SEMAINE, jour_str, 
                           COLONNE_DATE, date_str, 
                           COLONNE_HEURE, heure_str, 
                           COLONNE_MOTIF, motif_str, -1);
    }
    fclose(fichier);


    // Liaison du modèle de données au widget GtkTreeView
    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(toutesLignes));

    // Libération de la référence au modèle (le GtkTreeView maintiendra sa propre référence)
    g_object_unref(toutesLignes);
}
